package generar_estructuras

import (
	config "migra/pkg/config"
	model "migra/pkg/modeldb"
)


func genear_estructuras(){

	Config := config.Init()
	Config.CreateConnection()
	model.SetDB(config.DB())
	model.ActiveDB(config.DB())

	model.Generate("public", "*")
}
