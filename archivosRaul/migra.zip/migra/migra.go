package main

import (
    "bytes"
    "io/ioutil"
    "encoding/csv"
    "fmt"
    "log"
    "os"
    model "migra/pkg/modeldb"
    config "migra/pkg/config"
    "regexp"
)

func getFolders( Path string ) []string {
    var folders []string
    files, err := ioutil.ReadDir(Path)
    if err != nil {
        log.Fatal(err)
    }

    for _, file := range files {
	//if( file.IsDir() && file.Ext()==".csv" ){
	if( file.IsDir() ){
		folders = append( folders, file.Name() );
        }
    }
    return folders;
}

func getFiles( Path string ) []string {
    var files []string
    rows, err := ioutil.ReadDir(Path)
    if err != nil {
        log.Fatal(err)
    }

    for _, file := range rows {
        //fmt.Println(file.Name(), file.IsDir())

        r, err := regexp.MatchString(".csv", file.Name())
	if( !file.IsDir() && r && err==nil ){
		files = append( files, file.Name() );
        }
    }
    return files;
}

func readCsvFile(filePath string) [][]string {
    f, err := os.Open(filePath)
    if err != nil {
        log.Fatal("Unable to read input file " + filePath, err)
    }
    defer f.Close()

    csvReader := csv.NewReader(f)
    csvReader.Comma = ';'
    csvReader.FieldsPerRecord = -1
    // skip first line
    if _, err := csvReader.Read(); err != nil {
        return [][]string{}
    }

    records, err := csvReader.ReadAll()
    if err != nil {
        log.Fatal("Unable to parse file as CSV for " + filePath, err)
    }

    return records
}

func main() {

	Config := config.Init()
	Config.CreateConnection()
	model.SetDB(config.DB())
	model.ActiveDB(config.DB())

        model.Generate("public", "*")
        
        migra := model.NewEntity("newrol_liq")
        migra.Truncate()

    root:= "./Liquidaciones"

/*columns:=[...]string{"LEGAJO",
"NOMBRE_Y_APELLIDO",
"DOCUMENTO",
"CUIL",
"GRUPO_LIQUIDACION",
"DESCRIPCION_GRUPO_LIQUIDACION",
"CODIGO_TIPO_DE_PLANTA",
"DESCRIPCION_TIPO_DE_PLANTA",
"CODIGO_TIPO_DE_PUESTO",
"DESCRIPCION_TIPO_DE_PUESTO",
"CODIGO_GRUPO_PERSONAL",
"DESCRIPCION_GRUPO_PERSONAL",
"CODIGO_DE_FUNCION",
"DESCRIPCION_FUNCION",
"CODEP",
"DESCRIPCION_CODEP",
"CODIGO_DE_CONCEPTO",
"DESCRIPCION_DE_CONCEPTO",
"CODIGO_DE_ENTIDAD",
"DESCRIPCION_DE_ENTIDAD",
"UNIDADES",
"IMPORTE",
"ANO_MES_RETROACTIVO",
"ESCALAFON",
"CATEGORIA",
"DESCRIPCION"}
*/

    folders:=getFolders(root)
    fmt.Println(folders)
    //os.Exit(3)
    for _,folder := range folders{
       files:=getFiles(root+"/"+folder)
       month:=folder[0:2]
       year:=folder[2:]
       fmt.Println(len(folder),year,month)       

       for _,file := range files{
          fmt.Println(folder,file)
          type_liq:=file[0:1]
          company:=file[1:2]
          nro_liq:=file[2:5]
          records := readCsvFile(root+"/"+folder+"/"+file)
          for _,values := range records {
	     /*i:=0
             for _,value := range values {
		 fmt.Println("valor "+value) 
                fmt.Printf("i %d Columna %s valor %s\n",i,columns[i], value)
                i++
		if i >25{
                    break
                }
             }*/
             for i:=0; i<26; i++{
                 values[i]=fromWindows1252(values[i])
             }
             
             //fmt.Println(year,month,type_liq,company,nro_liq)
             //os.Exit(3)
             migra := model.NewEntity("newrol_liq")
             migra.SetValue("anio",year)
             migra.SetValue("mes",month)
             migra.SetValue("tipo_liq",type_liq)
             migra.SetValue("empresa",company)
             migra.SetValue("nro_liq",nro_liq)                                                    
             migra.SetValue("nro_legajo",values[0])
             migra.SetValue("apeynom",values[1])
             migra.SetValue("nro_doc",values[2])
             migra.SetValue("cuil",values[3])
             migra.SetValue("grupo_liq",values[4])
             migra.SetValue("desc_grupo_liq",values[5])
             migra.SetValue("cod_tipo_planta",values[6])
             migra.SetValue("desc_tipo_planta",values[7])
             migra.SetValue("cod_tipo_puesto",values[8])
             migra.SetValue("desc_tipo_puesto",values[9])
             migra.SetValue("cod_grupo_per",values[10])
             migra.SetValue("desc_grupo_per",values[11])
             migra.SetValue("cod_funcion",values[12])
             migra.SetValue("desc_funcion",values[13])
             migra.SetValue("codep",values[14])
             migra.SetValue("desc_codep",values[15])
             migra.SetValue("cod_concepto",values[16])
             migra.SetValue("desc_concepto",values[17])
             migra.SetValue("cod_entidad",values[18])
             migra.SetValue("desc_entidad",values[19])
             migra.SetValue("unidades",values[20])
             migra.SetValue("importe",values[21])
             migra.SetValue("aniomes_dev",values[22])
             migra.SetValue("escalafon",values[23])
             migra.SetValue("categoria",values[24])
             migra.SetValue("descripcion",values[25])
             migra.Insert("")
          }
       }
    }
}

func fromWindows1252(str string) string {
    var arr = []byte(str)
    var buf bytes.Buffer
    var r rune

    for _, b := range(arr) {
        switch b {
        case 0x80:
            r = 0x20AC
        case 0x82:
            r = 0x201A
        case 0x83:
            r = 0x0192
        case 0x84:
            r = 0x201E
        case 0x85:
            r = 0x2026
        case 0x86:
            r = 0x2020
        case 0x87:
            r = 0x2021
        case 0x88:
            r = 0x02C6
        case 0x89:
            r = 0x2030
        case 0x8A:
            r = 0x0160
        case 0x8B:
            r = 0x2039
        case 0x8C:
            r = 0x0152
        case 0x8E:
            r = 0x017D
        case 0x91:
            r = 0x2018
        case 0x92:
            r = 0x2019
        case 0x93:
            r = 0x201C
        case 0x94:
            r = 0x201D
        case 0x95:
            r = 0x2022
        case 0x96:
            r = 0x2013
        case 0x97:
            r = 0x2014
        case 0x98:
            r = 0x02DC
        case 0x99:
            r = 0x2122
        case 0x9A:
            r = 0x0161
        case 0x9B:
            r = 0x203A
        case 0x9C:
            r = 0x0153
        case 0x9E:
            r = 0x017E
        case 0x9F:
            r = 0x0178
        default:
            r = rune(b)
        }

        buf.WriteRune(r)
    }

    return string(buf.Bytes())
}
