package config

import (
	"database/sql"
	"fmt"
	"os"
	"runtime"

	_ "github.com/lib/pq"

	"github.com/spf13/viper"
)

type ConfigX struct {
	AppSeparator string

	DbHost     string
	DbPort     string
	DbUser     string
	DbPassword string
	DbName     string
}

var Config *ConfigX
var db *sql.DB

func Init() *ConfigX {
	Config = new(ConfigX)
	Config = SetDefaultConfig()
	return Config
}

// SetDefaultConfig ... levanta la configuracion al inicio del packager
//
func SetDefaultConfig() *ConfigX {

	viper.SetConfigType("toml")
	fh, err := os.Open("./config/config.conf")
	if err != nil {
		fmt.Println("Archivo de configuracion NO existe: ./config/config.conf")
	} else {
		err := viper.ReadConfig(fh)
		if err != nil {
			panic(err)
		}

		// Separador: Windows o Linux
		if runtime.GOOS == "windows" {
			Config.AppSeparator = "\\"
		} else {
			Config.AppSeparator = "/"
		}
		Config.DbHost = viper.GetString("db.host")
		Config.DbPort = viper.GetString("db.port")
		Config.DbUser = viper.GetString("db.user")
		Config.DbPassword = viper.GetString("db.password")
		Config.DbName = viper.GetString("db.name")

	}
	return Config
}

//--- metodo privado
func (this *ConfigX) getURLDB() string {
	return fmt.Sprintf("host=%s port=%s user=%s password=%s dbname=%s sslmode=disable",
		Config.DbHost, Config.DbPort, Config.DbUser, Config.DbPassword, Config.DbName)
}

//
//   Create and return a database conection
//
func (this *ConfigX) CreateConnection() {
	url := this.getURLDB()
	if connection, err := sql.Open("postgres", url); err != nil {
		fmt.Println("Error al conectarse a la base de datos")
		panic(err)
	} else {
		db = connection
	}
}

//
// Return sql.DB element.
//
func DB() *sql.DB {
	return db
}

func GetDBName() string {
	return Config.DbName
}
