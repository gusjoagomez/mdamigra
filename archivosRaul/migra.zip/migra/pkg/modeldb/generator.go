package modeldb

import (
	"database/sql"
	"fmt"
	"io/ioutil"
	"os"
	"strings"

	_ "github.com/lib/pq"
)

type fielddb struct {
	orden     int
	name      string
	required  bool
	dataType  string
	maxlength sql.NullInt64
	precision sql.NullInt64
	typef     string
}

type fkdb struct {
	name   string
	field  string
	tabler string
	fieldr string
}

var db *sql.DB

func SetDB(udb *sql.DB) {
	db = udb
}

// Generate ... Generate model files with tables definition.
// If parameter = * generate for ALL tables in database
// If comma list separated generate for these tables on list.
//
func Generate(schema, tables string) bool {

	list := processParamTables(schema, tables)
	for _, table := range list {
		if TableExists(schema, table) {
			fields := GetFieldsTable(table)
			relations := GetRelationsTable(table)
			entity := ModelDB{schema, table, fields, relations, nil}
			entity.SaveToYaml(DIR_DEFINE + table + ".yml")
			//generateCustomClass(dir, table)
		}
	}
	return true
}

// generateCustomClass ... genera una clase para manejar la tabla en un directorio
//
func generateCustomClass(dir, table string) {
	contentx, err := ioutil.ReadFile(dir + "model.tpl")
	if err != nil {
		panic(err)
	}

	content := string(contentx)

	entityname := strings.ReplaceAll(table, "_", "")
	file := strings.ToLower(entityname)
	entity := strings.Title(strings.ToLower(entityname))

	content = strings.ReplaceAll(content, "[ENTITY]", entity)
	content = strings.ReplaceAll(content, "[FUNCTION]", entity)
	content = strings.ReplaceAll(content, "[FILE]", table)

	f, err := os.Create("model/" + file + ".go")
	if err != nil {
		panic(err)
	}

	fmt.Println("Archivo generado: " + "model/" + file + ".go")

	_, err = f.WriteString(content)
	if err != nil {
		f.Close()
		panic(err)
		// return
	}
}

//  processParamTables ... Get an array of string where each element is a fieldname
//  If *=return ALL tables of database
//  If list comma separated return this tables in an array
//
func processParamTables(schema, tables string) []string {
	var res []string

	if tables == "*" {
		res = GetTableList(schema)
	} else {
		res = strings.Split(tables, ",")
	}
	return res
}

// getRelationsTable ... Get information about table/s by forein keys.
// Return: map of RelationDB where key=fieldname
//
func GetRelationsTable(table string) map[string]*RelationDB {
	var res = make(map[string]*RelationDB)
	var aux string
	//--- get foreing keys
	fks := GetInfoFk(table)
	for _, f := range fks {
		aux = strings.ReplaceAll(f.name, "_id", "")
		aux = strings.ReplaceAll(aux, "_", "")
		res[aux] = &RelationDB{[]string{f.field}, f.tabler, []string{f.fieldr}, ""}
	}
	return res
}

// getFieldsTable ... Get information about field of the table.
// Return: map where key is fieldname, value is a Fieldb struct
//
func GetFieldsTable(table string) map[string]*FieldDB {
	res := make(map[string]*FieldDB)
	//var pks []string
	var nombre string
	var espk = false
	var length int16
	var preci int8

	//-- retrieve Pks
	pks := GetInfoPk(table)

	//-- get Fields
	fields := getFields(table)
	for _, f := range fields {

		tipo := getTypeString(f)
		nombre = f.name
		_, espk = pks[nombre]
		if f.maxlength.Valid {
			length = int16(f.maxlength.Int64)
		}
		if f.precision.Valid {
			preci = int8(f.precision.Int64)
		}

		///Si es primarykey determina si tiene un sequencer o serial
		if espk {
			if HaveSequencer(table, f.name) != "" {
				tipo = "x"
			}
		}

		res[f.name] = &FieldDB{f.name, tipo, espk, f.required, length, preci, 0, nil}
	}

	return res
}

// getTypeString ... Get datatype's field
// Return a string: i=integer, b=boolean(1,0), s=string, t=timestamp, f=float
// otherwhise return s=string
//
func getTypeString(f fielddb) string {
	res := ""

	//fmt.Println(f.name, "tipo dato: ", f.typef)
	switch f.typef {
	case "int4":
		res = "i"
	case "int2":
		res = "b"
	case "bool":
		res = "b"
	case "bpchar":
		res = "s"
	case "varchar":
		res = "s"
	case "text":
		res = "s"
	case "date":
		res = "d"
	case "timestamp":
		res = "t"
	case "numeric":
		res = "f"
	default:
		res = "s"
	}
	return res
}

func SchemaExists(schema string) bool {
	sql := fmt.Sprintf("SELECT schema_name FROM information_schema.schemata WHERE schema_name = '%s'", schema)
	rows, err := db.Query(sql)
	defer rows.Close()

	if err != nil {
		panic(err)
	}
	return rows.Next()
}

//  TableExists ... Check the existance of the table
//  Return true: table exists, false: table does not exists
//
func TableExists(schema, table string) bool {
	sql := fmt.Sprintf("SELECT tablename FROM pg_catalog.pg_tables WHERE schemaname='"+schema+"' AND tablename='%s' order by tablename", table)
	rows, err := db.Query(sql)
	defer rows.Close()

	if err != nil {
		panic(err)
	}
	return rows.Next()
}

// getTableList ... Get the ALL table names from database and public schema.
// TODO: pass parameter to return another schema different to public
//
func GetTableList(schema string) []string {
	var tables []string
	sql := "SELECT tablename FROM pg_catalog.pg_tables WHERE schemaname='" + schema + "' order by tablename"
	rows, err := db.Query(sql)
	defer rows.Close()

	if err != nil {
		panic(err)
	}

	for rows.Next() {
		table := ""
		rows.Scan(&table)
		tables = append(tables, table)
	}
	return tables
}

// getInfoPk ... Get information about primary key table.
// Parameter: tablename
// Return a map with key:value where both are the primary key fieldname.
//
func GetInfoPk(table string) map[string]string {

	pks := make(map[string]string)
	sql := "SELECT c.column_name FROM information_schema.table_constraints tc " +
		"JOIN information_schema.constraint_column_usage AS ccu USING (constraint_schema, constraint_name) " +
		"JOIN information_schema.columns AS c ON c.table_schema = tc.constraint_schema AND tc.table_name = c.table_name AND ccu.column_name = c.column_name " +
		"WHERE constraint_type = 'PRIMARY KEY' and tc.table_name ='%s'"
	sql = fmt.Sprintf(sql, table)
	rows, _ := db.Query(sql)
	defer rows.Close()

	for rows.Next() {
		pk := ""
		rows.Scan(&pk)
		pks[pk] = pk //pks[] = append(pks, pk)
	}
	return pks
}

//  getInfoFk ... Get information of forein key tables.
//  Use this function to get the relationship with other tables.
//  Return: array of fkdb structure
//
func GetInfoFk(table string) []fkdb {
	var fks []fkdb
	sql := "SELECT kcu.column_name as fname, ccu.table_name AS tabler, ccu.column_name AS fnamepk " +
		"FROM information_schema.table_constraints AS tc JOIN information_schema.key_column_usage AS kcu " +
		"ON tc.constraint_name = kcu.constraint_name JOIN information_schema.constraint_column_usage AS ccu ON ccu.constraint_name = tc.constraint_name " +
		"WHERE constraint_type = 'FOREIGN KEY' AND tc.table_name='%s'"
	sql = fmt.Sprintf(sql, table)

	rows, _ := db.Query(sql)
	//defer rows.Close();

	for rows.Next() {
		fk := fkdb{}
		rows.Scan(&fk.field, &fk.tabler, &fk.fieldr)
		fk.name = fk.field
		fks = append(fks, fk)
	}
	return fks
}

// getFields ... Get all table fields
// Return an fieldb array. That is table information
//
func getFields(table string) []fielddb {
	var fields []fielddb
	var nulstr string

	sql := fmt.Sprintf("SELECT ordinal_position as orden, column_name as field, is_nullable as null, data_type, character_maximum_length, numeric_precision, udt_name as type FROM information_schema.columns WHERE table_name ='%s'", table)
	rows, _ := db.Query(sql)
	defer rows.Close()

	for rows.Next() {
		field := fielddb{}
		rows.Scan(&field.orden, &field.name, &nulstr, &field.dataType, &field.maxlength, &field.precision, &field.typef)
		field.required = (nulstr == "NO")
		fields = append(fields, field)
	}
	return fields
}

func HaveSequencer(table, field string) string {
	var defaultname string = ""

	//table_schema ='%s' and
	sql := fmt.Sprintf("SELECT column_default  FROM information_schema.columns  WHERE table_name ='%s' and column_name ='%s'", table, field)
	rows, _ := db.Query(sql)
	defer rows.Close()

	for rows.Next() {
		rows.Scan(&defaultname)
	}

	//nextval('"seguridadUsuarioSeq"'::regclass)
	defaultname = strings.Replace(defaultname, "nextval(", "", -1)
	defaultname = strings.Replace(defaultname, "::regclass)", "", -1)
	defaultname = strings.Replace(defaultname, "'", "", -1)
	defaultname = strings.Replace(defaultname, "\"", "", -1)
	defaultname = strings.TrimSpace(defaultname)

	return defaultname
}

func GetFieldsListComma(table string) string {
	var lista string = ""
	var campo string

	sql := fmt.Sprintf("SELECT column_name as field FROM information_schema.columns WHERE table_name ='%s'", table)
	rows, _ := db.Query(sql)
	defer rows.Close()

	for rows.Next() {
		rows.Scan(&campo)
		if lista == "" {
			lista = campo
		} else {
			lista = lista + ", " + campo
		}
	}
	return lista
}
