package modeldb

import (
	"database/sql"
	"encoding/json"
	"fmt"
	"io/ioutil"
	"strconv"
	"strings"
	"time"

	_ "github.com/lib/pq"

	yaml "gopkg.in/yaml.v2"
)

const DIR_DEFINE = "./app/modeldef/"

var DBM *sql.DB // DB Conection Model

// DatatableGrid -- estructura para mostrar en datatables
type DatatableGrid struct {
	Draw            int                      `json:"draw"`
	RecordsTotal    int                      `json:"recordsTotal"`
	RecordsFiltered int                      `json:"recordsFiltered"`
	Data            []map[string]interface{} `json:"data"`
}

// ModelDB --- Representa una entidad con tabla, campos y relaciones
type ModelDB struct {
	Schema    string                 `json:"Schema"    yaml:"Schema"`
	Table     string                 `json:"Table"     yaml:"Table"`
	Fields    map[string]*FieldDB    `json:"Fields"    yaml:"Fields"`
	Relations map[string]*RelationDB `json:"Relations" yaml:"Relations"`
	Tx        *sql.Tx                ///transaccion
}

// FieldDB ... Representa informacion de campos de la tabla
type FieldDB struct {
	Name      string `json:"Name"      yaml:"Name"`      //nombre de campo en tabla
	Ftype     string `json:"Ftype"     yaml:"Ftype"`     //Tipo: i:integer, s: string, b:boolean, t:time
	Key       bool   `json:"Key"       yaml:"Key"`       //es campo PK
	Required  bool   `json:"Required"  yaml:"Required"`  //requerido: 0:no 1:yes
	Length    int16  `json:"Length"    yaml:"Length"`    //Largo del campo
	Precision int8   `json:"Precision" yaml:"Precision"` //Precision
	API       uint8  `json:"Api"       yaml:"Api"`       //0: nada, 1:retorna en api, 2: solo escribe API, 3: lee y escribe
	Value     interface{}
}

// RelationDB ... Representa una relacion entre dos entidades
type RelationDB struct {
	Fieldsl  []string `json:"Fieldsl"  yaml:"Fieldsl"`  //fields local
	Tabler   string   `json:"Tabler"   yaml:"Tabler"`   //table related
	Fieldsr  []string `json:"Fieldsr"  yaml:"Fieldsr"`  //fields related
	Criteria string   `json:"Criteria" yaml:"Criteria"` //extra criteria
}

// ActiveDB -- cambia la conexion activa modelDB
func ActiveDB(activeDb *sql.DB) {
	DBM = activeDb
}

//
// Find several records according Criteria
// Return: map order numeric with fieldname and value
//
func (entity *ModelDB) Find(criteria string) []map[string]interface{} {
	sql := entity.FindSQL(criteria, "", "", 1)
	result := ExeQuery(sql, entity.Tx)
	return result
}

func (entity *ModelDB) FindOrder(criteria, orderby string) []map[string]interface{} {
	sql := entity.FindSQL(criteria, "", orderby, 1)
	result := ExeQuery(sql, entity.Tx)
	return result
}

// FindForGrid --
func (entity *ModelDB) FindForGrid(fields, criteria string) DatatableGrid {
	sql := entity.FindSQL(criteria, fields, "", 1)
	result := ExeQuery(sql, entity.Tx)
	ret := DatatableGrid{
		Draw: 1, RecordsTotal: len(result), RecordsFiltered: len(result), Data: result,
	}
	return ret
}

//FindFields ... Ejecuta una consulta y retorna lista de campos
func (entity *ModelDB) FindFields(criteria, fields string) []map[string]interface{} {

	sql := entity.FindSQL(criteria, fields, "", 1)
	result := ExeQuery(sql, entity.Tx)

	return result
}

// FindOne ... Find a unique record according Criteria
// Return: array related record
func (entity *ModelDB) FindOne(criteria string) map[string]interface{} {

	var result map[string]interface{}
	result = make(map[string]interface{})

	sql := entity.FindSQL(criteria, "", "", 1)
	sql = sql + " LIMIT 1"
	//fmt.Println(sql)
	resultdb := ExeQuery(sql, entity.Tx)
	// fmt.Println("****RESULTADO****")
	// fmt.Println(resultdb)
	// fmt.Println("*****************")

	if len(resultdb) > 0 {
		result = resultdb[0]
	}

	return result
}

// FindOneFields ... Find a unique record according Criteria
// Return: array related record
//
func (entity *ModelDB) FindOneFields(criteria, fields string) map[string]interface{} {

	sql := entity.FindSQL(criteria, fields, "", 1)
	sql = sql + " LIMIT 1"
	resultdb := ExeQuery(sql, entity.Tx)
	if len(resultdb) > 0 {
		return (resultdb[0])
	} else {
		return nil
	}
}

// FindOneByRelation ... Retorna un solo registro de datos segun:
// criteria, fields y relaciones
//
func (entity *ModelDB) FindOneByRelation(criteria, fields, rels string) map[string]interface{} {
	sql := entity.FindSQLRelations(criteria, fields, rels)
	sql = sql + " LIMIT 1"
	resultdb := ExeQuery(sql, entity.Tx)
	if len(resultdb) > 0 {
		return (resultdb[0])
	} else {
		return nil
	}
}

// FindByRelation ... Retorna un conjunto de datos segun:
// criteria, fields y relaciones
//
func (entity *ModelDB) FindByRelation(criteria, fields, rels string) []map[string]interface{} {
	sql := entity.FindSQLRelations(criteria, fields, rels)
	resultdb := ExeQuery(sql, entity.Tx)
	return resultdb
}

// Return: array related record
//
func (entity *ModelDB) Load(criteria, order string) (bool, map[string]interface{}) {

	var exist bool
	sql := entity.FindSQL(criteria, "", order, 1)
	sql = sql + " LIMIT 1"

	resultdb := ExeQuery(sql, entity.Tx)
	result := resultdb[0]

	for k, v := range result {
		_, exist = entity.Fields[k]
		if exist {
			(entity.Fields[k]).Value = v
			//entity.SetValue(k, v)
		}
	}
	return exist, result
}

// FindMax ... Find the maximum value in a field according criteria
// Return: array related record
//
func (entity *ModelDB) FindMax(criteria, fields string) []map[string]interface{} {

	//	pks := entity.GetPK()
	sql := entity.FindSQL(criteria, fields, "", 1)
	result := ExeQuery(sql, entity.Tx)

	return result
}

// CountsValues ... Retorna la cantidad de registros segun criteria
//
func (entity *ModelDB) CountsValues(criteria string) int64 {

	//	var ret int
	sql := entity.FindSQL(criteria, "count(*) as qty", "", 1)
	result := ExeQuery(sql, entity.Tx)
	val := result[0]

	cantidad := val["qty"].(int64)
	// ret = val["qty"]
	return cantidad
}

// GetPK ... Find the Entity's PrimaryKeys
// Return: array related primary keys
//
func (entity *ModelDB) GetPK() []string {
	var res []string

	for _, fdb := range entity.Fields {
		if fdb.Key {
			res = append(res, fdb.Name)
		}
	}
	return res
}

// GetPKList ... Find the Entity's PrimaryKeys
// Return: sting comma separated primary keys
//
func (entity *ModelDB) GetPKList() string {
	res := ""
	for _, campo := range entity.GetPK() {
		if res == "" {
			res = res + campo
		} else {
			res = res + "," + campo
		}
	}
	return res
}

// ExeQuery ... Execute query and return values in a map.
//
func ExeQuery(sqlstr string, tx *sql.Tx) []map[string]interface{} {
	var rows *sql.Rows
	var err error

	if tx == nil {
		rows, err = DBM.Query(sqlstr) // Note: Ignoring errors for brevity
	} else {
		rows, err = tx.Query(sqlstr) // Note: Ignoring errors for brevity
	}

	if err != nil {
		fmt.Println("*********************\n***** SQL ERROR *****\n*********************")
		fmt.Println("SQL: " + sqlstr)
		fmt.Println("PanicError: ")
		panic(err)
	}
	defer rows.Close()

	columns, _ := rows.Columns()
	count := len(columns)
	values := make([]interface{}, count)
	valuePtrs := make([]interface{}, count)

	finalResult := []map[string]interface{}{}

	for rows.Next() {
		//recore las columnas
		for i := range columns {
			valuePtrs[i] = &values[i]
		}
		rows.Scan(valuePtrs...)

		tmpStruct := map[string]interface{}{}

		for i, col := range columns {
			var v interface{}
			val := values[i]
			b, ok := val.([]byte)
			if ok {
				v = string(b)
			} else {
				v = val
			}
			tmpStruct[col] = v //fmt.Sprintf("%s", v)
		}

		finalResult = append(finalResult, tmpStruct)
	}
	return finalResult
}

// ExeQueryString ... Execute query and return values in a map.
//
func ExeQueryString(sql string) []map[string]string {

	rows, _ := DBM.Query(sql) // Note: Ignoring errors for brevity

	columns, _ := rows.Columns()

	count := len(columns)
	values := make([]interface{}, count)
	valuePtrs := make([]interface{}, count)

	finalResult := []map[string]string{}

	for rows.Next() {
		for i := range columns {
			valuePtrs[i] = &values[i]
		}
		rows.Scan(valuePtrs...)

		tmpStruct := map[string]string{}

		for i, col := range columns {
			var v interface{}
			val := values[i]
			b, ok := val.([]byte)
			if ok {
				v = string(b)
			} else {
				v = val
			}
			tmpStruct[col] = fmt.Sprintf("%v", v)
		}
		finalResult = append(finalResult, tmpStruct)
	}
	return finalResult
}

// getFieldsSQL ... Retrieve field list in a string comma separated values
//
func (entity *ModelDB) getFieldsSQL() string {
	res := ""
	for _, fdb := range entity.Fields {
		if res == "" {
			res = fdb.Name
		} else {
			res = res + "," + fdb.Name
		}
	}
	return res
}

// NewEntity ... Create and return an element ModelDB from definition file
//
func NewEntity(filename string) ModelDB {
	entity := new(ModelDB)
	entity.LoadFromYaml(DIR_DEFINE + filename + ".yml")

	return *entity
}

// LoadFromYaml ... Initialize structure ModelDB from yml sfile
// Return error when something is wrong
//
func (entity *ModelDB) LoadFromYaml(filename string) error {
	bytes, err := ioutil.ReadFile(filename)
	if err != nil {
		panic(err)
	}

	err = yaml.Unmarshal(bytes, entity)
	if err != nil {
		return err
	}

	// if entity.Schema != "" {
	// 	entity.Table = entity.Schema + "." + entity.Table
	// }

	return err
}

// SaveToYaml ... Save to yml file in case of generate ModelDB file definition
//
func (entity *ModelDB) SaveToYaml(filename string) error {
	bytes, err := yaml.Marshal(entity)
	if err != nil {
		panic(err)
	}
	return ioutil.WriteFile(filename, bytes, 0644)
}

// SaveToJSON ... Save to json file in case of generate ModelDB file definition
//
func (entity *ModelDB) SaveToJSON(filename string) error {
	//bytes, err := json.MarshalIndent(entity, "", "  ")
	bytes, err := json.Marshal(entity)
	if err != nil {
		return err
	}
	return ioutil.WriteFile(filename, bytes, 0644)
}

// DumpValues ... Muestra valores de la entidad
func (entity *ModelDB) DumpValues() {
	data, _ := json.Marshal(entity)
	fmt.Printf("%s\n", data)
}

// FindSQL ... Generate sql query to find record according Criteria
// Return: string with sql query generated
// TODO: orderby, relation, limit, regxpg
//
func (entity *ModelDB) FindSQL(criteria, fields, orderby string, page int) string {
	sql := ""
	if page == 0 {
		page = 0
	}

	if (fields == "") || (fields == "*") {
		fields = entity.getFieldList(",", "", "")
	}

	sql = "SELECT " + fields + " FROM " + entity.Schema + "." + entity.Table + " WHERE 1=1 "
	if criteria != "" {
		sql += " AND " + criteria
	}
	if orderby != "" {
		sql += " ORDER BY " + orderby
	}

	return sql
}

// FindSQLRelations ... Generate sql query to find record according Criteria
// Return: string with sql query generated
// TODO: orderby, relation, limit, regxpg
//
func (entity *ModelDB) FindSQLRelations(criteria, fields, relations string) string {

	var rel *RelationDB
	var sql, lefjoin, fieldsrels string

	//--- Genera LEFT JOIN
	rels := strings.Split(relations, ",")
	for _, r := range rels {
		r = strings.Trim(r, " ")
		rel = entity.Relations[r]
		lefjoin += "\n LEFT JOIN " + entity.Schema + "." + rel.Tabler + " ON "
		for k, f := range rel.Fieldsl {
			lefjoin += rel.Tabler + "." + rel.Fieldsr[k] + "=" + entity.Table + "." + f
		}
		//--trae campos de la tabla relacion
		fieldsrels += ", " + entity.getFieldsByRel(rel.Tabler, r)
	}

	if (fields == "") || (fields == "*") {
		fields = entity.getFieldList(",", "T.FasF", "")
		fields += fieldsrels
	}

	sql = "SELECT " + fields + " FROM " + entity.Schema + "." + entity.Table + " \n" + lefjoin + "\n WHERE 1=1 "
	if criteria != "" {
		sql += " AND " + criteria
	}
	return sql
}

// getFieldsByRel ... Trae los campos de las relaciones y devuelve concatenado con los campos
//
func (entity *ModelDB) getFieldsByRel(rel, alias string) string {
	aux := ModelDB{}
	aux.LoadFromYaml("model/define/" + rel + ".yml")
	fieldList := aux.getFieldList(",", "T.FasA_F", alias)
	return fieldList
}

// getFieldList ... Generate field list in comma (or other separator) separated format
// Return: string list with a separator.
//
func (entity *ModelDB) getFieldList(separator, format, alias string) string {

	var element, list string
	if format == "" {
		format = "F"
	}

	for _, f := range entity.Fields {
		if format == "F" {
			element = "\"" + f.Name + "\""
		} else if format == "FasT_F" {
			element = f.Name + " as " + entity.Table + "_" + f.Name
		} else if format == "T.FasT_F" {
			element = entity.Table + "." + f.Name + " as " + entity.Table + "_" + f.Name
		} else if format == "T.FasA_F" {
			element = entity.Table + "." + f.Name + " as " + alias + "_" + f.Name
		} else if format == "T.FasF" {
			element = entity.Table + "." + f.Name + " as " + f.Name
		} else if format == "T.F" {
			element = entity.Table + "." + f.Name
		}

		if list == "" {
			list += element
		} else {
			list += separator + element
		}
	}
	return list
}

// FindValuesSelect ... Generate a map with Key=>Value to implement on Select html component
// Return: string list with a separator.
//
func (entity *ModelDB) FindValuesSelect(kk, kv, criteria, order string) map[string]string {

	result := make(map[string]string)

	fields := kk + "," + kv
	sql := entity.FindSQL(criteria, fields, order, 1)
	// if order != "" {
	// 	sql = sql + " ORDER BY " + order

	// }
	resdb := ExeQuery(sql, entity.Tx)
	for _, valrec := range resdb {

		k := valrec[kk].(string)
		v := valrec[kv].(string)
		result[k] = v
	}
	return result
}

// SetValues ... Set values for record
// Return true of false
//
func (entity *ModelDB) SetValues(data map[string]interface{}) bool {
	var exist bool
	for k, v := range data {
		_, exist = entity.Fields[k]
		if exist {
			(entity.Fields[k]).Value = v
		}
	}
	return true
}

// SetValue ... Set values for record
// Return true of false
//
func (entity *ModelDB) SetValue(field string, d interface{}) bool {
	entity.Fields[field].Value = d
	return true
}

func (entity *ModelDB) GetValue(field string) interface{} {
	return entity.Fields[field].Value
}

func (entity *ModelDB) SetIFExist(fieldname string, value interface{}) {
	_, exist := entity.Fields[fieldname]
	if exist {
		entity.Fields[fieldname].Value = value
	}
}

// BeforeInsert ... Configure fields like: createdAt, updatedAt, etc
//
func (entity *ModelDB) BeforeInsert() {
	now := time.Now()
	//--- CREATED ----
	entity.SetIFExist("createdat", now)
	entity.SetIFExist("updatedat", now) //en insert tambien inicializo fecha modificado
}

// BeforeUpdate ... Configure fields like: updatedAt, etc
//
func (entity *ModelDB) BeforeUpdate() {

	now := time.Now()
	//--- UPDATED ---
	entity.SetIFExist("updatedat", now)
	//entity.SetIFExist("updated_by",userID)
}

// Insert ... Insert values configured in Fields.
// Return the max value of field passed by param
// Return -1 when error
//
func (entity *ModelDB) Insert(fieldMax string) int64 {

	var params []interface{}
	var err error
	var res int64 = -1
	var fields, parstr = "", ""
	var logx string
	cant := 0

	entity.BeforeInsert()

	for _, v := range entity.Fields {
		///Si es key y ademas un serial no agrega en Insert
		if v.Key && (v.Ftype == "x") {
			continue
		}

		cant++
		if parstr != "" {
			parstr += ","
			fields += ","
		}
		fields += "\"" + v.Name + "\""
		parstr += "$" + strconv.Itoa(cant)
		params = append(params, v.Value)
		logx += fmt.Sprintf("%s = %v  \n", v.Name, v.Value)
	}

	sql := "INSERT INTO " + entity.Schema + "." + entity.Table + " (" + fields + ") VALUES ( " + parstr + ")"
	//fmt.Println(sql)
	if entity.Tx != nil {
		_, err = entity.Tx.Exec(sql, params...)
	} else {
		_, err = DBM.Exec(sql, params...)
	}
	if err != nil {
		fmt.Println("Error Insert:", err)
		fmt.Println(sql)
		fmt.Println(params...)
		fmt.Println(logx)
		//panic(err)
		return -1
	}
	if fieldMax != "" {
		r := entity.FindOneFields("1=1", "max("+fieldMax+") as id")
		// var numstr = r["id"]
		// resx, err := strconv.ParseInt(numstr, 10, 64)
		resx := r["id"]
		if err != nil {
			panic(err)
		} else {
			res = resx.(int64)
		}
	} else {
		res = 0 ///insert sin pedir ultimo numero
	}
	return res
}

// Update ... Ejecuta un update sobre base de datos segun criteria
//
func (entity *ModelDB) Update(criteria string) bool {
	res := false
	var params []interface{}
	var keys = entity.GetPK()
	var wherestr string
	entity.BeforeUpdate()

	if criteria != "" {
		wherestr = criteria
	} else {
		wherestr = ""
	}

	fields := ""
	cant := 0
	for _, v := range entity.Fields {
		cant++

		if isKey(v.Name, keys) {
			if wherestr != "" {
				wherestr += " AND "
			}
			wherestr = wherestr + "\"" + v.Name + "\"" + " = $" + strconv.Itoa(cant)
			params = append(params, v.Value)
			continue
		} else {
			if fields != "" {
				fields += ","
			}
			fields += "\"" + v.Name + "\"" + "= $" + strconv.Itoa(cant)

			//fmt.Println(v.Name, v.Value)
			params = append(params, v.Value)
		}
	}

	sql := "UPDATE " + entity.Schema + "." + entity.Table + " SET " + fields + "  WHERE " + wherestr
	_, err := DBM.Exec(sql, params...)
	if err != nil {
		panic(err)
	} else {
		res = true
	}

	//fmt.Println(params...)

	return res
}

func (entity *ModelDB) Truncate() bool{
	res:=true
        sql := "TRUNCATE " + entity.Schema + "." + entity.Table 
	_, err := DBM.Exec(sql)
	if err != nil {
		panic(err)
	} else {
		res = true
	}
	return res
}

// Delete ... Borra Registro segun PrimaryKey
//
func (entity *ModelDB) Delete() bool {

	res := true
	var params []interface{}
	var criteria = map[string]interface{}{
		"id": 5,
	}
	var keys = entity.GetPK()

	wherestr := ""
	fields := ""
	cant := 0

	for k, v := range criteria {
		cant++
		if isKey(k, keys) {
			if wherestr != "" {
				wherestr += " AND "
			}
			wherestr = k + " = $" + strconv.Itoa(cant)
			params = append(params, v)
			continue
		} else {
			if fields != "" {
				fields += ","
			}
			fields += k + "= $" + strconv.Itoa(cant)
			params = append(params, v)
		}
	}

	sql := "DELETE FROM " + entity.Schema + "." + entity.Table + " WHERE " + wherestr
	//fmt.Println(sql)
	_, err := DBM.Exec(sql, params...)
	if err != nil {
		panic(err)
	}
	return res
}

// DeleteByCriteria ... Borra segun criteria
//
func (entity *ModelDB) DeleteByCriteria(criteria map[string]interface{}) bool {

	res := true
	var params []interface{}
	var keys = entity.GetPK()

	wherestr := ""
	fields := ""
	cant := 0

	for k, v := range criteria {
		cant++
		if isKey(k, keys) {
			if wherestr != "" {
				wherestr += " AND "
			}
			wherestr = k + " = $" + strconv.Itoa(cant)
			params = append(params, v)
			continue
		} else {
			if fields != "" {
				fields += ","
			}
			fields += k + "= $" + strconv.Itoa(cant)
			params = append(params, v)
		}
	}

	sql := "DELETE FROM " + entity.Schema + "." + entity.Table + " WHERE " + wherestr
	//fmt.Println(sql)
	_, err := DBM.Exec(sql, params...)
	if err != nil {
		panic(err)
	}
	return res
}

// DiscoverRelationsNN ... Detecta relaciones Muchos a Muchos
//
func (entity *ModelDB) DiscoverRelationsNN(projectName, schema string) {

	sql := "SELECT distinct tablename FROM " + schema + ".xch_tmpfields xt WHERE tablename IN ( " +
		"SELECT tablename FROM " + schema + ".xch_tmpfields xt GROUP BY projectname ,tablename " +
		"HAVING count(*)=2 " +
		") AND ftable is not null AND fkey is not null AND projectname='" + projectName + "'"
	relaciones := ExeQuery(sql, entity.Tx)
	for _, tabla := range relaciones {
		entity.GenerarRelacionNN(projectName, schema, tabla["tablename"].(string))
	}
}

func (entity *ModelDB) GenerarRelacionNN(projectName, schema, tablename string) {
	sql := "SELECT tablename , fieldname ,ftable, fkey FROM " + schema + ".xch_tmpfields xt " +
		"WHERE projectname='" + projectName + "' AND tablename='" + tablename + "'"
	reldata := ExeQuery(sql, entity.Tx)
	var paso = 1
	var rel1p1, rel1p2, rel2p1, rel2p2 string = "", "", "", ""
	var rel1, rel2 map[string]string

	rel1 = make(map[string]string)
	rel2 = make(map[string]string)

	//tablename:seguridadRol, fname:id, tabler:seguridadRolPermiso, fkey: rolId:seguridadRol.id,permisoId:seguridadPermiso.id
	for _, tabla := range reldata {
		if paso == 1 {
			rel1["tablename"] = tabla["ftable"].(string)
			rel1["fname"] = tabla["fkey"].(string)
			rel1["tabler"] = tabla["tablename"].(string)
			rel1p2 = tabla["fieldname"].(string) + ":" + tabla["ftable"].(string) + "." + tabla["fkey"].(string)
			rel2p2 = tabla["fieldname"].(string) + ":" + tabla["ftable"].(string) + "." + tabla["fkey"].(string)
		} else {
			rel2["tablename"] = tabla["ftable"].(string)
			rel2["fname"] = tabla["fkey"].(string)
			rel2["tabler"] = tabla["tablename"].(string)
			rel2["fkey"] = tabla["fieldname"].(string) + ":" + tabla["ftable"].(string) + "." + tabla["fkey"].(string)
			rel1p1 = tabla["fieldname"].(string) + ":" + tabla["ftable"].(string) + "." + tabla["fkey"].(string)
			rel2p1 = tabla["fieldname"].(string) + ":" + tabla["ftable"].(string) + "." + tabla["fkey"].(string)
		}
		paso++
	}
	rel1["fkey"] = rel1p1 + ", " + rel1p2
	rel2["fkey"] = rel2p1 + ", " + rel2p2

	entidadrel := NewEntity("xch_tmprels")
	entidadrel.SetValue("projectname", projectName)
	entidadrel.SetValue("tablename", rel1["tablename"])
	entidadrel.SetValue("typerel", "N:N")
	entidadrel.SetValue("fname", rel1["fname"])
	entidadrel.SetValue("tabler", rel1["tabler"])
	entidadrel.SetValue("fnamepk", rel1["fkey"])
	dato := entidadrel.Find("projectname='" + projectName + "' AND tablename='" + rel1["tablename"] + "' AND typerel='N:N' AND fname='" + rel1["fname"] + "' AND tabler='" + rel1["tabler"] + "'")
	if len(dato) > 0 {
		entidadrel.Update("projectname='" + projectName + "' AND tablename='" + rel1["tablename"] + "' AND typerel='N:N' AND fname='" + rel1["fname"] + "' AND tabler='" + rel1["tabler"] + "'")
	} else {
		entidadrel.Insert("")
	}

	entidadrel = NewEntity("xch_tmprels")
	entidadrel.SetValue("projectname", projectName)
	entidadrel.SetValue("tablename", rel2["tablename"])
	entidadrel.SetValue("typerel", "N:N")
	entidadrel.SetValue("fname", rel2["fname"])
	entidadrel.SetValue("tabler", rel2["tabler"])
	entidadrel.SetValue("fnamepk", rel2["fkey"])
	dato = entidadrel.Find("projectname='" + projectName + "' AND tablename='" + rel2["tablename"] + "' AND typerel='N:N' AND fname='" + rel2["fname"] + "' AND tabler='" + rel2["tabler"] + "'")
	if len(dato) > 0 {
		entidadrel.Update("projectname='" + projectName + "' AND tablename='" + rel2["tablename"] + "' AND typerel='N:N' AND fname='" + rel2["fname"] + "' AND tabler='" + rel2["tabler"] + "'")
	} else {
		entidadrel.Insert("")
	}

}

func ToMapString(data map[string]interface{}) map[string]string {
	result := map[string]string{}
	for k := range data {
		if v, ok := data[k].(string); ok {
			result[k] = v
		}
	}
	return result
}

func isKey(k string, keys []string) bool {
	isk := false
	for _, v := range keys {
		if v == k {
			isk = true
			break
		}
	}
	return isk
}
