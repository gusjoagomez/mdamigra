package modeldb

/**
  Class for Entity: Test
*/

type Test struct {
	ModelDB
}

func NewTest() Test {
	entity := Test{}
	entity.LoadFromYaml("model/define/test.yml")
	return entity
}
