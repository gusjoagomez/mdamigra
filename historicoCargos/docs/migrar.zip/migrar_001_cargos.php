<?php

$lst_TipoDoc = traerTiposEquivalentes('TIPO_DOC',$db2);
$lst_Genero = traerTiposEquivalentes('GENERO',$db2);

$sql="SELECT pf.id, pf.nombres|| ' ' || pf.apellido as nombre_apellido, 
        case  when (nro_doc::text='') or (nro_doc is null) then 'No' else 'Si'end as tiene_dni,
        case  when (nro_doc::text='') or (nro_doc is null) then 'No se cuenta con esta información' else '' end as motivo_no_dni,
        pf.tipo_documento_id tipo_doc, pf.nro_doc nro_doc, pf.cuit_cuil cuil, pf.sexo_id identidad_genero,
        pf.fecha_nac fecha_nacimiento,
        '' lugar_nacimiento,
        ( select pc.telefono as telefono_contacto from datos_persona_fisica_contacto pc where pc.persona_fisica_id =pf.id  limit 1 ) as telefono_contacto,
        ( select pc.nombre|| ' ' || pc.apellido as nombre_contacto from datos_persona_fisica_contacto pc where pc.persona_fisica_id =pf.id  limit 1 ) as nombre_contacto,
        pf.fecha_registro fecha_ingreso, '' situacion_persona,
        pf.id, pf.tipo_cuit_cuil_id, pf.sexo_id, pf.estado_civil_id, pf.nacionalidad_id,  
        pf.tipo_cobertura_medica_id, pf.version_compuesta, pf.version_datos_persona_fisica,   pf.fecha_eliminacion, pf.hash, 
        pf.version_domicilio
    FROM public.persona_fisica pf 
    WHERE TRUE";


$datos = DB_query($sql,$db1);


$aux = TraerVectorIds($db2, "persona_id", "asistido_alta");
$existe = array_flip($aux);

while ($row = DB_fetch($datos))
{
    $id=$row['id'];
    $domi = traerDomicilio($id, $db1 );
    $row = preProcesarRow($row,$lst_Genero, $lst_TipoDoc);

    if (isset($existe[$id])){
        actualizar_AltaDispositivo($db1,$db2,$row,$domi);
    }else{
        insertar_AltaDispositivo($db1,$db2,$row,$domi);
    }
}
//--- CERRAR TRANSACCION ---
//-----------------------------------------------------------------------------


function preProcesarRow($row,$lst_Genero, $lst_TipoDoc){

    if ($row['tipo_doc']!=''){ 
        $row['tipo_doc'] = $lst_TipoDoc["{$row['tipo_doc']}"];
    }
    
    $row['identidad_genero'] = $lst_Genero[ $row['identidad_genero'] ];

    return $row;
}

function insertar_AltaDispositivo($db1,$db2,$r,$domi){

$dCalle='';
$dNro='0';
$dDepto='';
$dPartido='';
$dProvincia='';

$fechaNac= ($r['fecha_nacimiento']!='')?"'".$r['fecha_nacimiento']."'":'NULL';
$nombreApellido = str_replace("'","",$r['nombre_apellido']);
$CUIL = ($r['cuil']!='')?$r['cuil']:'NULL';
$NRODOC = (trim($r['nro_doc'])!='')?$r['nro_doc']:'0';
$NRODOC = preg_replace('/\D/', '', $NRODOC);

$dCalle= $domi['domicilio_calle'];
$dNro=$domi['domicilio_numero'];
$dDepto= $domi['depto_casa'];
$dPartido= $domi['domicilio_partido'];
$dProvincia= $domi['domicilio_provincia'];


echo "\n".$nombreApellido;
$sql="INSERT INTO public.asistido_alta
        ( persona_id, nombre_apellido, tiene_dni, motivo_no_dni, tipo_doc, nro_doc, cuil, 
          identidad_genero, fecha_nacimiento, lugar_nacimiento, telefono_contacto, nombre_contacto, 
          fecha_ingreso, situacion_persona, domicilio_calle, domicilio_numero, depto_casa, domicilio_partido, 
          domicilio_provincia, situacion_hab, situacion_hab_notrat, nucleo_convivencia, ocupacion, 
          cobertura_medica, tiene_dificultad, posee_cud, posse_pension_nocon, plan_social, nivel_estudios, 
          esta_estudiando, tratamiento_previo, tratamiento_cuantos, dispositivos_tratamiento, lugar_tratamiento, 
          tipo_tratamiento, tiempo_tratamiento, tratamiento_saludmental, desde_donde, 
          sustancia_consumo, sustancia_consumo2, frecuencia_consumo, sugerencia_terapeutica, sugerencia_terapeutica2 )
     VALUES({$r['id']}, '{$nombreApellido}', '{$r['tiene_dni']}', '{$r['motivo_no_dni']}', '{$r['tipo_doc']}', $NRODOC, $CUIL, 
     '{$r['identidad_genero']}', {$fechaNac}, '{$r['lugar_nacimiento']}', '{$r['telefono_contacto']}', '{$r['nombre_contacto']}', 
     '{$r['fecha_ingreso']}', '{$r['situacion_persona']}', '{$dCalle}', {$dNro}, '{$dDepto}', '{$dPartido}', 
     '{$dProvincia}', '', '', '', '', '', '', '', '', '', '', '', '', 0, '', '', '', '', '', '', '', '', '', '', '');
    ";
    echo "\nINSERT:\n".$sql."\n--------------";
    $datos=DB_query( $sql, $db2 );
}

function actualizar_AltaDispositivo($db1,$db2,$row,$domi){

}


/**
 * Trae el ultimo domiciliio de la persona
 */
function traerDomicilio($id, $db1 )
{
    $result = array('domicilio_calle'=>'','domicilio_numero'=>0,'depto_casa'=>'','domicilio_partido'=>'','domicilio_provincia'=>'');

    $sql="select calle domicilio_calle, nro domicilio_numero, dpto depto_casa, 
        localidad_id, l.nombre domicilio_localidad, 
        m.nombre domicilio_partido,
        p.nombre domicilio_provincia
    from domicilio_persona_fisica dpf 
        left join domicilio d on d.id=dpf.domicilio_id
        left join localidad l on l.id =d.localidad_id
        left join municipio m on m.id =l.municipio_id
        left join provincia p on p.id =l.provincia_id 
    where dpf.persona_fisica_id={$id} and dpf.fecha_desde =(
                select max(x.fecha_desde)
                from domicilio_persona_fisica x 
                where x.persona_fisica_id =dpf.persona_fisica_id 
        )";
    $datos = DB_query($sql,$db1);
    if($datos){
        $result = DB_fetch($datos);
        if(!$result){
            $result = array('domicilio_calle'=>'','domicilio_numero'=>0,'depto_casa'=>'','domicilio_partido'=>'','domicilio_provincia'=>'');
        }
    }

    $result['domicilio_numero']=(trim($result['domicilio_numero'])=='')?0:preg_replace('/\D/', '',$result['domicilio_numero']);
    if($result['domicilio_numero']=='') $result['domicilio_numero']=0;
    
    return $result;
}



function traerDatosComplementarios($id, $db1 )
{
    $sql="SELECT dd.id, dato_complementario, value
          FROM encabezado_poblacion_datos_complementarios epdc
               left join persona_fisica_poblacion_datos_complementarios dc on dc.encabezado_poblacion_datos_complementarios_id =epdc.id 
               left join poblacion_datos_complementarios dd on dd.id = dc.poblacion_datos_complementarios_id 
          WHERE epdc.persona_fisica_id =265 and epdc.fecha_registro = (
                SELECT MAX(e.fecha_registro) fecha_registro FROM encabezado_poblacion_datos_complementarios e WHERE e.persona_fisica_id=epdc.persona_fisica_id
                )";
    $datos = DB_query($sql,$db1);
    $result = DB_fetch($datos);
    return $result;
}



function traerSeguimientoPersona($persona_id, $db1 )
{
    $sql="SELECT  * 
        FROM seguimiento_persona_fisica spf 
        LEFT JOIN seguimiento_dimension_personal sdp on sdp.id= spf.dimension_personal_id 
        LEFT JOIN seguimiento_dimension_psico_social sdps on sdps.id= spf.dimension_psico_social_id  
        LEFT JOIN seguimiento_dimension_situacional sds on sds.id= spf.dimension_situacional_id
        LEFT JOIN seguimiento_dimension_terapeutica sdt on sdt.id= spf.dimension_terapeutica_id
        LEFT JOIN seguimiento_dimension_terapeutica_sustancia_consumo sdtsc on sdtsc.seguimiento_dimension_terapeutica_id =sdt.id
        LEFT JOIN sustancia_consumo sc on sc.id = sdtsc.sustancia_consumo_id and 
                spf.fecha_alta IN ( SELECT min(fecha_alta) FROM seguimiento_persona_fisica pf WHERE pf.id=$persona_id )
        WHERE spf.persona_fisica_id = $persona_id
        ";
    $datos = DB_query($sql,$db1);
    $result = DB_fetch($datos);
    return $result;
}