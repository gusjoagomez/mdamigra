<?php

/***
 * 
DROP TABLE public.tmp_dispositivo;
CREATE TABLE public.tmp_dispositivo (
	id int4 NULL,
	provincia_id int4 NULL,
	provincia varchar(255) NULL,
	departamento_id int4 NULL,
	municipio_id int4 NULL,
	localidad_id int4 NULL,
	localidad varchar(255) NULL,
	nombre varchar(255) NULL,
	tiposocietario_id int4 NULL,
	tiposocietario varchar(255) NULL,
	modalidad varchar(512) NULL,
	domicilio_id int4 NULL,
    domicilio varchar(512) NULL,
    dom_calle varchar(255) NULL,
    dom_nro varchar(255) NULL,
    dom_piso varchar(255) NULL,
    dom_depto varchar(255) NULL,
	telefono varchar(255) NULL,
	email varchar(255) NULL
);
*/

$archivo =__DIR__."/data/listadoCT.csv";
$datos = DB_query("DELETE FROM tmp_dispositivo WHERE 1=1",$db1);
//--- Leer el archivo ---
$gestor = fopen($archivo, "r");
if ($gestor)
{
    $nroLinea=1;
    $cantidad=0;
    $rdb = limpiarRegistroDB();

    $reg = traerRegistro($gestor);
    while ( (!feof($gestor)) and ($reg!=false))
    {
        $rdb["provincia"]      = $reg["provincia"];
        $rdb["localidad"]      = $reg["localidad"];
        $rdb["nombre"]         = $reg["nombre"];
        $rdb["tipoSocietario"] = $reg["tipoSocietario"];
        do{
            $rdb["modalidad"] .= ($rdb["domicilio"]=="")?$reg["modalidad"]:", ".$reg["modalidad"];
            $rdb["domicilio"] .= ($rdb["domicilio"]=="")?$reg["domicilio"]:" ".$reg["domicilio"];
            $rdb["telefono"]  .= ($rdb["telefono"]=="")?$reg["telefono"]:" ".$reg["telefono"];
            $rdb["email"]     .= ($rdb["email"]=="")?$reg["email"]:" ".$reg["email"];
    
            $reg = traerRegistro($gestor);

        }while( ($reg["nombre"]=="") and (!feof($gestor)) and ($reg!=false) );

        $cantidad++;
        insertarRegistro($cantidad,$db1,$rdb);
        $rdb = limpiarRegistroDB();
    }//-while 

    echo  "[ procesados: ".$cantidad." ]";
}//---gestor archivo
fclose($gestor);
//--- CERRAR TRANSACCION ---



//-----------------------------------------------------------------------------
function insertarRegistro($cantidad,$db1,$rdb)
{
    echo "\n------------------------------";
    print_r($rdb);
    echo "\n------------------------------";    
    $sql="INSERT into tmp_dispositivo ( id,provincia_id, provincia, localidad_id,localidad,nombre,tiposocietario_id,tiposocietario,modalidad,domicilio,telefono,email ) ".
         "VALUES ( $cantidad, 0, '{$rdb["provincia"]}',0, '{$rdb["localidad"]}', '{$rdb["nombre"]}', 0,'{$rdb["tipoSocietario"]}', '{$rdb["modalidad"]}', '{$rdb["domicilio"]}', '{$rdb["telefono"]}', '{$rdb["email"]}' )";
    $datos=DB_query( $sql, $db1 );
}


function limpiarRegistroDB()
{
    $rdb["provincia"]      = "";
    $rdb["localidad"]      = "";
    $rdb["nombre"]         = "";
    $rdb["tipoSocietario"] = "";
    $rdb["modalidad"]      = "";
    $rdb["domicilio"]      = "";
    $rdb["telefono"]       = "";
    $rdb["email"]          = "";
    return $rdb;
}

function leer_linea($gestor)
{
    $linea = fgets($gestor, 4096);
    $linea = mb_convert_encoding($linea, "UTF8");
    return (trim($linea)!="")?$linea:false;
}

function traerRegistro($gestor,$separador="|")
{
    $linea = leer_linea($gestor);
    if ($linea!=false){
        $r =  explode($separador,$linea);
        $ret["provincia"]     = trim($r[0]);
        $ret["localidad"]     = trim($r[1]);
        $ret["nombre"]        = trim($r[2]);
        $ret["tipoSocietario"]= trim($r[3]);
        $ret["modalidad"]     = trim($r[4]);
        $ret["domicilio"]     = trim($r[5]);
        $ret["telefono"]      = trim($r[6]);
        $ret["email"]         = trim($r[7]);
    }else{
        $ret = false;
    }

    return $ret;
}
