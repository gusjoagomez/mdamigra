<?php

/***
 * INSERTA DATOS EN TABLA
create table dispositivo_alta(
    dispositivo_id integer,
 	nombre varchar(100) not null,
 	tipo_dispositivo varchar(4) not null,
 	poblacion_edad varchar(1024) not null,
 	poblacion_especifica varchar(1024) not null
 );
 */


$sql="select d.id dispositivo_id, razon_social  as nombre, td.nombre AS tipo_dispositivo
    from dispositivo d 
        left join persona_juridica pj on pj.id = d.persona_juridica_id 
        left join tipo_dispositivo td on td.id = d.tipo_dispositivo_id
    where d.fecha_eliminacion IS NULL
    ";
$datos = DB_query($sql,$db1);

$aux = TraerVectorIds($db2, "dispositivo_id", "dispositivo_alta");
$existe = array_flip($aux);

while ($row = DB_fetch($datos)){

    $id=$row['dispositivo_id'];
    if (isset($existe[$id])){
        actualizar_AltaDispositivo($db1,$db2,$row);
    }else{
        insertar_AltaDispositivo($db1,$db2,$row);
    }
}
//--- CERRAR TRANSACCION ---
//-----------------------------------------------------------------------------



/**
 * Inserta registro
 */
function insertar_AltaDispositivo($db1,$db2,$row)
{
    $poblacionEdad =traerDispositivoPoblacionEdad($db1,$row['dispositivo_id']);
    $poblacionEspec=traerDispositivoPoblacionEspecial($db1,$row['dispositivo_id']);

    $sql="INSERT INTO public.dispositivo_alta(dispositivo_id, nombre, tipo_dispositivo, poblacion_edad, poblacion_especifica)
         VALUES({$row['dispositivo_id']}, '{$row['nombre']}', '{$row['tipo_dispositivo']}', '{$poblacionEdad}', '{$poblacionEspec}')";

    $datos=DB_query( $sql, $db2 );
}

/**
 * Actualiza registro
 */
function actualizar_AltaDispositivo($db1,$db2,$row)
{
    $poblacionEdad =traerDispositivoPoblacionEdad($db1,$row['dispositivo_id']);
    $poblacionEspec=traerDispositivoPoblacionEspecial($db1,$row['dispositivo_id']);

    $sql="UPDATE public.dispositivo_alta SET 
            nombre = '{$row['nombre']}', tipo_dispositivo= '{$row['tipo_dispositivo']}', poblacion_edad='{$poblacionEdad}',  poblacion_especifica='{$poblacionEspec}'
         WHERE dispositivo_id = {$row['dispositivo_id']}";

    $datos=DB_query( $sql, $db2 );
}

/**
 * Trae la poblacion de los dispositivo que atendio en su historia
 */
function traerDispositivoPoblacionEdad($db1,$dispositivoId)
{
    $result='';
    $sql="SELECT DISTINCT 
           CASE
                WHEN date_part('year',age(pf.fecha_nac))  > 0 and date_part('year',age(pf.fecha_nac))  < 11  THEN 'Niño/a'
                WHEN date_part('year',age(pf.fecha_nac))  >= 11 and date_part('year',age(pf.fecha_nac))  < 20  THEN 'Adolecente' 
                WHEN date_part('year',age(pf.fecha_nac))  >= 20 and date_part('year',age(pf.fecha_nac))  < 69  THEN 'Adulto'
                WHEN date_part('year',age(pf.fecha_nac))  >= 70   THEN 'Adulto+70'
           ELSE '' 
                END AS poblacion_edad
         FROM movimientos_asistidos ma 
                left join  persona_fisica pf on pf.id = ma.persona_fisica_id
        WHERE ma.dispositivo_destino_id = {$dispositivoId} and ma.fecha_eliminacion is not null";

     $datos = DB_query($sql,$db1);
     while ($row = DB_fetch($datos)){
         if($result!=''){
             $result.=', ';
         }
         $result.=$row['poblacion_edad'];
     }
     return $result;
 }


/**
 * Trae detalle de poblacion especial que atendio
 */
function traerDispositivoPoblacionEspecial($db1,$dispositivoId)
{
   $result='';
   $sql="select distinct pdc.id, pdc.dato_complementario 
        from encabezado_poblacion_datos_complementarios epdc 
            left join persona_fisica_poblacion_datos_complementarios pfpdc on pfpdc.encabezado_poblacion_datos_complementarios_id=epdc.id 
            left join poblacion_datos_complementarios pdc on pdc.id =pfpdc.poblacion_datos_complementarios_id 
        where epdc.dispositivo_registrante_id = {$dispositivoId} and pfpdc.value is not null
        order by pdc.id";

    $datos = DB_query($sql,$db1);
    while ($row = DB_fetch($datos)){
        if($result!=''){
            $result.=', ';
        }
        $result.=$row['dato_complementario'];
    }
    return $result;
}

